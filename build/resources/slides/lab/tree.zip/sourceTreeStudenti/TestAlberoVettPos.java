
import java.util.Iterator;

public class TestAlberoVettPos {

public static void main(String[] args) {
	
		
		
		Albero A1 = new AlberoVettPos(3);
		Albero A2 = new AlberoVettPos(3);
		Albero A3 = new AlberoVettPos(3);
		Albero A4 = new AlberoVettPos(3);
		Albero A5 = new AlberoVettPos(3);
		Albero A6 = new AlberoVettPos(3);
		Albero A7 = new AlberoVettPos(3);
		Albero A8 = new AlberoVettPos(3);
		Albero A9 = new AlberoVettPos(3);
		Albero A10 = new AlberoVettPos(3);
	
		Albero A11 = new AlberoVettPos(3);
		Albero A12 = new AlberoVettPos(3);
		Albero A13 = new AlberoVettPos(3);
		Albero A14 = new AlberoVettPos(3);
		Albero A15 = new AlberoVettPos(3);
		Albero A16 = new AlberoVettPos(3);
		Albero A17 = new AlberoVettPos(3);
		Albero A18 = new AlberoVettPos(3);
		Albero A19 = new AlberoVettPos(3);
		Albero A20 = new AlberoVettPos(3);
		
		
		Albero A21 = new AlberoVettPos(3);
		Albero A22 = new AlberoVettPos(3);
		Albero A23 = new AlberoVettPos(3);
		Albero A24 = new AlberoVettPos(3);
		Albero A25 = new AlberoVettPos(3);
		Albero A26 = new AlberoVettPos(3);
		Albero A27 = new AlberoVettPos(3);
		Albero A28 = new AlberoVettPos(3);
		Albero A29 = new AlberoVettPos(3);
		Albero A30 = new AlberoVettPos(3);
		
		System.out.println("Albero 1");
		
		A1.insRadice("1");
		A2.insRadice("2");
		A3.insRadice("3");
		A4.insRadice("4");
		A5.insRadice("5");
		A6.insRadice("6");
		A7.insRadice("7");
		A8.insRadice("8");
		A9.insRadice("9");
		A10.insRadice("10");
		A11.insRadice("11");
		A12.insRadice("12");
		A13.insRadice("13");
		A14.insRadice("14");
		A15.insRadice("15");
		A16.insRadice("16");
		A17.insRadice("17");
		A18.insRadice("18");
		A19.insRadice("19");
		A20.insRadice("20");
		A21.insRadice("21");
		A22.insRadice("22");
		A23.insRadice("23");
		A24.insRadice("24");
		A25.insRadice("25");
		A26.insRadice("26");
		A27.insRadice("27");
		A28.insRadice("28");
		A29.insRadice("29");
		A30.insRadice("30");
		
		
		A5.insprimoSottoAlbero(A5.radice(), A16);
		A5.insprimoSottoAlbero(A5.radice(), A15);
		A5.insprimoSottoAlbero(A5.radice(), A14);
		
		A6.insprimoSottoAlbero(A6.radice(), A19);
		A6.insprimoSottoAlbero(A6.radice(), A18);
		A6.insprimoSottoAlbero(A6.radice(), A17);
		
		
		A7.insprimoSottoAlbero(A7.radice(), A22);
		A7.insprimoSottoAlbero(A7.radice(), A21);
		A7.insprimoSottoAlbero(A7.radice(), A20);
		
		A8.insprimoSottoAlbero(A8.radice(), A25);
		A8.insprimoSottoAlbero(A8.radice(), A24);
		A8.insprimoSottoAlbero(A8.radice(), A23);
		
		A9.insprimoSottoAlbero(A9.radice(), A28);
		A9.insprimoSottoAlbero(A9.radice(), A27);
		A9.insprimoSottoAlbero(A9.radice(), A26);
		
		A10.insprimoSottoAlbero(A10.radice(), A30);
		
		A10.insprimoSottoAlbero(A10.radice(), A29);
		
		A2.insprimoSottoAlbero(A2.radice(), A7);
		A2.insprimoSottoAlbero(A2.radice(), A6);
		A2.insprimoSottoAlbero(A2.radice(), A5);
		
		
		A3.insprimoSottoAlbero(A3.radice(), A10);
		A3.insprimoSottoAlbero(A3.radice(), A9);
		A3.insprimoSottoAlbero(A3.radice(), A8);
		
		A4.insprimoSottoAlbero(A4.radice(), A13);
		A4.insprimoSottoAlbero(A4.radice(), A12);
		A4.insprimoSottoAlbero(A4.radice(), A11);
		
		
		A1.insprimoSottoAlbero(A1.radice(), A4);
		A1.insprimoSottoAlbero(A1.radice(), A3);
		A1.insprimoSottoAlbero(A1.radice(), A2);
		
		
		Iterator it=((AlberoVettPos)A1).iterator();
		while(it.hasNext()){
			NodoVPos v=(NodoVPos)it.next();
			System.out.println(v);
		}
		
		
		System.out.println("Albero 2");
		
		Albero B1 = new AlberoVettPos(3);
		Albero B2 = new AlberoVettPos(3);
		Albero B3 = new AlberoVettPos(3);
		Albero B4 = new AlberoVettPos(3);
		Albero B5 = new AlberoVettPos(3);
		
		
		B1.insRadice("1");
		B2.insRadice("2");
		B3.insRadice("3");
		B4.insRadice("4");
		B5.insRadice("5");
		try{
			B1.insprimoSottoAlbero(B1.radice(), B5);
			B1.insprimoSottoAlbero(B1.radice(), B4);
			B1.insprimoSottoAlbero(B1.radice(), B3);
			B1.insprimoSottoAlbero(B1.radice(), B2);
		}
		catch(AritaNonValidaException e){
			System.out.println(e);			
		}
		
		it=((AlberoVettPos)B1).iterator();
		while(it.hasNext()){
			NodoVPos v=(NodoVPos)it.next();
			System.out.println(v);
		}
		
		
		System.out.println("Albero 3");
		
		Albero A = new AlberoVettPos(4);
		Albero B = new AlberoVettPos(4);
		Albero C = new AlberoVettPos(4);
		Albero D = new AlberoVettPos(4);
		Albero E = new AlberoVettPos(4);
		Albero F = new AlberoVettPos(4);
		Albero G = new AlberoVettPos(4);
		Albero H = new AlberoVettPos(4);
		Albero I = new AlberoVettPos(4);
		Albero L = new AlberoVettPos(4);
	
		
		A.insRadice("A");
		B.insRadice("B");
		C.insRadice("C");
		D.insRadice("D");
		E.insRadice("E");
		F.insRadice("F");
		G.insRadice("G");

		H.insRadice("H");
		I.insRadice("I");
		L.insRadice("L");
		
			
		B.insprimoSottoAlbero(B.radice(), D);
		A.insprimoSottoAlbero(A.radice(), B);
		
		F.insprimoSottoAlbero(F.radice(), G);
		C.insprimoSottoAlbero(C.radice(), E);
		C.insSottoAlbero(C.primoFiglio(C.radice()), F);
		A.insSottoAlbero(A.primoFiglio(A.radice()), C);
		
		A.insSottoAlbero(A.succFratello(A.primoFiglio(A.radice())), H);
		
		I.insprimoSottoAlbero(I.radice(), L);
		
		A.insSottoAlbero(A.succFratello(A.primoFiglio(A.radice())), I);
		
		it=((AlberoVettPos)A).iterator();
		while(it.hasNext()){
			NodoVPos v=(NodoVPos)it.next();
			System.out.println(v);
		}
		
		
		System.out.println("Potature del sottalbero di 3 radicato in C");
		A.cancSottoAlbero(A.succFratello(A.primoFiglio(A.radice())));
	
		
		it=((AlberoVettPos)A).iterator();
		while(it.hasNext()){
			NodoVPos v=(NodoVPos)it.next();
			System.out.println(v);
		}
		
		System.out.println("Potature del sottalbero di 3 radicato in H");
		A.cancSottoAlbero(A.succFratello(A.succFratello(A.primoFiglio(A.radice()))));
		
		it=((AlberoVettPos)A).iterator();
		while(it.hasNext()){
			NodoVPos v=(NodoVPos)it.next();
			System.out.println(v);
		}
		
		
		
		
		
		System. out.println("Albero 4");
		
		Albero M = new AlberoVettPos(3);
		Albero N = new AlberoVettPos(3);
		Albero O = new AlberoVettPos(3);
		
		M.insRadice("A");
		N.insRadice("B");
		O.insRadice("C");
		
		M.insprimoSottoAlbero(M.radice(), N);
		M.insSottoAlbero(M.primoFiglio(M.radice()), O);
		
		it=((AlberoVettPos)M).iterator();
		while(it.hasNext()){
			NodoVPos v=(NodoVPos)it.next();
			System.out.println(v);
		}
		
		System.out.println("Ricerca primo figlio della radice di albero 3 nell' albero 4");
		try{
			M.primoFiglio(A.radice());
		}
		catch(EccezioneNodoInvalido e)
		{
			System.out.println(e);
		}
		catch(RuntimeException e)
		{
			System.out.println(e);
		}
		
		
		System.out.println("Potatura del sottalbero di 3 radicato in radice");
		A.cancSottoAlbero(A.radice());
		
		
		
		it=((AlberoVettPos)A).iterator();
		while(it.hasNext()){
			NodoVPos v=(NodoVPos)it.next();
			System.out.println(v);
		}
		
		
		

	}

}
