

public interface Nodo {

}
