
import java.util.Iterator;

public class TestBinTree {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		
		AlberoBinPF A = new AlberoBinPF();
		AlberoBinPF B = new AlberoBinPF();
		AlberoBinPF C = new AlberoBinPF();
		AlberoBinPF D = new AlberoBinPF();
		AlberoBinPF E = new AlberoBinPF();
		AlberoBinPF F = new AlberoBinPF();
		AlberoBinPF G = new AlberoBinPF();
		AlberoBinPF H = new AlberoBinPF();
		AlberoBinPF I = new AlberoBinPF();
		AlberoBinPF L = new AlberoBinPF();
	
		AlberoBinPF M = new AlberoBinPF();
		AlberoBinPF N = new AlberoBinPF();
		AlberoBinPF O = new AlberoBinPF();
		
		
		A.aggiungiRadice("A");
		B.aggiungiRadice("B");
		C.aggiungiRadice("C");
		D.aggiungiRadice("D");
		E.aggiungiRadice("E");
		F.aggiungiRadice("F");
		G.aggiungiRadice("G");
		H.aggiungiRadice("H");
		I.aggiungiRadice("I");
		L.aggiungiRadice("L");
		M.aggiungiRadice("M");
		N.aggiungiRadice("N");
		O.aggiungiRadice("O");
		
		
		
		I.innestaDes(I.radice(), O);
		G.innestaSin(G.radice(),H);
		G.innestaDes(G.radice(), I);
		
		C.innestaSin(C.radice(), F);		
		C.innestaDes(C.radice(), G);
		
		A.innestaDes(A.radice(), C);
		A.innestaSin(A.radice(), B);
		
		D.innestaSin(D.radice(), N);
		E.innestaSin(E.radice(), L);
		E.innestaDes(E.radice(), M);
		
		A.innestaSin(A.sin(A.radice()), D);
		A.innestaDes(A.sin(A.radice()), E);
		
		Iterator it=((AlberoBinPF)A).iterator();
		while(it.hasNext()){
			NodoBinPF v=(NodoBinPF)it.next();
			System.out.println(v);
		}
		
		
		System.out.println("Pota l'albero radicato in N");
		A.pota(A.sin(A.sin(A.sin(A.radice()))));
		it=((AlberoBinPF)A).iterator();
		while(it.hasNext()){
			NodoBinPF v=(NodoBinPF)it.next();
			System.out.println(v);
		}
		
		System.out.println("Pota l'albero radicato in B");
		A.pota(A.sin(A.radice()));
		
		it=((AlberoBinPF)A).iterator();
		while(it.hasNext()){
			NodoBinPF v=(NodoBinPF)it.next();
			System.out.println(v);
		}
		
		System.out.println("Pota l'albero radicato in F");
		A.pota(A.sin(A.des(A.radice())));
		
		it=((AlberoBinPF)A).iterator();
		while(it.hasNext()){
			NodoBinPF v=(NodoBinPF)it.next();
			System.out.println(v);
		}
		
		System.out.println("Pota l'albero radicato in A");
		A.pota(A.radice());
		
		it=((AlberoBinPF)A).iterator();
		while(it.hasNext()){
			NodoBinPF v=(NodoBinPF)it.next();
			System.out.println(v);
		}
		
	}

}
