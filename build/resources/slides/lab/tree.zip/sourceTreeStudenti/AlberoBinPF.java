import java.util.Iterator;

public class AlberoBinPF implements AlberoBin, Iterable {
	private NodoBinPF radice = null;

	
	public void aggiungiRadice(Object info) {
		if (radice != null) throw new EccezioneNodoEsistente();
		radice = new NodoBinPF(info);
		radice.albero = this;
		
	}

	
	public boolean alberoVuoto() {
		return radice==null;
	}

	
	public void cambiaInfo(Nodo v, Object info) {
		if (checkNode(v)) throw new EccezioneNodoInvalido();
		((NodoBinPF) v).info = info;
		
	}

	
	
	
	public Object info(Nodo v) {
		if (checkNode(v)) throw new EccezioneNodoInvalido();
		return ((NodoBinPF)v).info;
	}

	
	private void updateIdAlbero(Nodo u){
		((NodoBinPF)u).albero=this;
		if (sin(u)!=null)
		{
	      updateIdAlbero(sin(u));
		}
		if (des(u)!=null)
		{
			updateIdAlbero(des(u));
		}
		
	}
	public void innestaSin(Nodo u, AlberoBin a) {
		 if (checkNode(u)) throw new EccezioneNodoInvalido();
			NodoBinPF z = (NodoBinPF) u;
			if (!sinVuoto(z)) throw new EccezioneNodoEsistente();
			if (a.alberoVuoto()) return; //albero vuoto
			z.sin = (NodoBinPF) a.radice();
			
			((AlberoBinPF)a).radice = null; // rimuovo riferiemnto ad oggetto			
			updateIdAlbero(z.sin); // modifico l'appartenenza dei nodi di a 
			z.sin.padre = z;
		
	}


	
	public Nodo padre(Nodo v) {
		  if (checkNode(v)) throw new EccezioneNodoInvalido();
		  return ((NodoBinPF) v).padre;
	}

	
	public void pota(Nodo v) {
		if (checkNode(v)) throw new EccezioneNodoInvalido();
		NodoBinPF vpf = (NodoBinPF)v;
		if (vpf == radice)  radice = null;
		else {
			if (vpf.padre.sin == v) vpf.padre.sin = null;
			else vpf.padre.des = null;
			vpf.padre = null;
		}
	}

	
	public Nodo radice() {
		return radice;
	}

	
	public Nodo sin(Nodo v) {
		if (checkNode(v)) throw new EccezioneNodoInvalido();
		return ((NodoBinPF)v).sin;

	}
	
	private boolean checkNode(Nodo v) {
		if (v == null)
			return true;//ecc
		if (((NodoBinPF) v).albero != this)
			return true;
		return false;
	}


	public boolean desVuoto(Nodo u) {
		
		return ((NodoBinPF)u).des==null;
	}



	public boolean sinVuoto(Nodo u) {
		return ((NodoBinPF)u).sin==null;
	}

	public Iterator iterator() {		
		return new BinTreeIterator(this);
	}
	
	// implementazione dei metodi da parte degli Studenti

	public Nodo des(Nodo v) {
		//da impementare
	}

	public void innestaDes(Nodo u, AlberoBin a) {
		 //da implementare
	}

	

}
