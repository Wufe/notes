
public interface AlberoBin {

	public boolean alberoVuoto();

	public Nodo radice();

	public Nodo padre(Nodo v);

	public Nodo sin(Nodo v);

	public Nodo des(Nodo v);

	public void innestaSin(Nodo u, AlberoBin albero);

	public void innestaDes(Nodo u, AlberoBin albero);

	public boolean sinVuoto(Nodo u);
	
	public boolean desVuoto(Nodo u);

	public void pota(Nodo v);

	public Object info(Nodo v);

	public void cambiaInfo(Nodo v, Object info);

	public void aggiungiRadice(Object info);

	
}
