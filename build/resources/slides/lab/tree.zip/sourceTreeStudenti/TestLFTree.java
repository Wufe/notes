import java.util.Iterator;






public class TestLFTree {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Albero A1 = new AlberoPFFS();
		Albero A2 = new AlberoPFFS();
		Albero A3 = new AlberoPFFS();
		Albero A4 = new AlberoPFFS();
		Albero A5 = new AlberoPFFS();
		Albero A6 = new AlberoPFFS();
		Albero A7 = new AlberoPFFS();
		Albero A8 = new AlberoPFFS();
		Albero A9 = new AlberoPFFS();
		Albero A10 = new AlberoPFFS();
	
		Albero A11 = new AlberoPFFS();
		Albero A12 = new AlberoPFFS();
		Albero A13 = new AlberoPFFS();
		Albero A14 = new AlberoPFFS();
		Albero A15 = new AlberoPFFS();
		Albero A16 = new AlberoPFFS();
		Albero A17 = new AlberoPFFS();
		Albero A18 = new AlberoPFFS();
		Albero A19 = new AlberoPFFS();
		Albero A20 = new AlberoPFFS();
		
		
		Albero A21 = new AlberoPFFS();
		Albero A22 = new AlberoPFFS();
		Albero A23 = new AlberoPFFS();
		Albero A24 = new AlberoPFFS();
		Albero A25 = new AlberoPFFS();
		Albero A26 = new AlberoPFFS();
		Albero A27 = new AlberoPFFS();
		Albero A28 = new AlberoPFFS();
		Albero A29 = new AlberoPFFS();
		Albero A30 = new AlberoPFFS();
		
		System.out.println("Albero 1");
		
		A1.insRadice("1");
		A2.insRadice("2");
		A3.insRadice("3");
		A4.insRadice("4");
		A5.insRadice("5");
		A6.insRadice("6");
		A7.insRadice("7");
		A8.insRadice("8");
		A9.insRadice("9");
		A10.insRadice("10");
		A11.insRadice("11");
		A12.insRadice("12");
		A13.insRadice("13");
		A14.insRadice("14");
		A15.insRadice("15");
		A16.insRadice("16");
		A17.insRadice("17");
		A18.insRadice("18");
		A19.insRadice("19");
		A20.insRadice("20");
		A21.insRadice("21");
		A22.insRadice("22");
		A23.insRadice("23");
		A24.insRadice("24");
		A25.insRadice("25");
		A26.insRadice("26");
		A27.insRadice("27");
		A28.insRadice("28");
		A29.insRadice("29");
		A30.insRadice("30");
		
		
		A5.insprimoSottoAlbero(A5.radice(), A16);
		A5.insprimoSottoAlbero(A5.radice(), A15);
		A5.insprimoSottoAlbero(A5.radice(), A14);
		
		A6.insprimoSottoAlbero(A6.radice(), A19);
		A6.insprimoSottoAlbero(A6.radice(), A18);
		A6.insprimoSottoAlbero(A6.radice(), A17);
		
		
		A7.insprimoSottoAlbero(A7.radice(), A22);
		A7.insprimoSottoAlbero(A7.radice(), A21);
		A7.insprimoSottoAlbero(A7.radice(), A20);
		
		A8.insprimoSottoAlbero(A8.radice(), A25);
		A8.insprimoSottoAlbero(A8.radice(), A24);
		A8.insprimoSottoAlbero(A8.radice(), A23);
		
		A9.insprimoSottoAlbero(A9.radice(), A28);
		A9.insprimoSottoAlbero(A9.radice(), A27);
		A9.insprimoSottoAlbero(A9.radice(), A26);
		
		A10.insprimoSottoAlbero(A10.radice(), A30);
		
		A10.insprimoSottoAlbero(A10.radice(), A29);
		
		A2.insprimoSottoAlbero(A2.radice(), A7);
		A2.insprimoSottoAlbero(A2.radice(), A6);
		A2.insprimoSottoAlbero(A2.radice(), A5);
		
		
		A3.insprimoSottoAlbero(A3.radice(), A10);
		A3.insprimoSottoAlbero(A3.radice(), A9);
		A3.insprimoSottoAlbero(A3.radice(), A8);
		
		A4.insprimoSottoAlbero(A4.radice(), A13);
		A4.insprimoSottoAlbero(A4.radice(), A12);
		A4.insprimoSottoAlbero(A4.radice(), A11);
		
		
		A1.insprimoSottoAlbero(A1.radice(), A4);
		A1.insprimoSottoAlbero(A1.radice(), A3);
		A1.insprimoSottoAlbero(A1.radice(), A2);
		
		
		Iterator it=((AlberoPFFS)A1).iterator();
		while(it.hasNext()){
			NodoPFFS v=(NodoPFFS)it.next();
			System.out.println(v);
		}
		
		
		System.out.println("Albero 2");
		
		Albero B1 = new AlberoPFFS();
		Albero B2 = new AlberoPFFS();
		Albero B3 = new AlberoPFFS();
		Albero B4 = new AlberoPFFS();
		Albero B5 = new AlberoPFFS();
		
		
		B1.insRadice("1");
		B2.insRadice("2");
		B3.insRadice("3");
		B4.insRadice("4");
		B5.insRadice("5");

		B1.insprimoSottoAlbero(B1.radice(), B5);
		B1.insprimoSottoAlbero(B1.radice(), B4);
		B1.insprimoSottoAlbero(B1.radice(), B3);
		B1.insprimoSottoAlbero(B1.radice(), B2);
		
	
		
		it=((AlberoPFFS)B1).iterator();
		while(it.hasNext()){
			NodoPFFS v=(NodoPFFS)it.next();
			System.out.println(v);
		}
		
		
		System.out.println("Albero 3");
		
		Albero A = new AlberoPFFS();
		Albero B = new AlberoPFFS();
		Albero C = new AlberoPFFS();
		Albero D = new AlberoPFFS();
		Albero E = new AlberoPFFS();
		Albero F = new AlberoPFFS();
		Albero G = new AlberoPFFS();
		Albero H = new AlberoPFFS();
		Albero I = new AlberoPFFS();
		Albero L = new AlberoPFFS();
	
		
		A.insRadice("A");
		B.insRadice("B");
		C.insRadice("C");
		D.insRadice("D");
		E.insRadice("E");
		F.insRadice("F");
		G.insRadice("G");

		H.insRadice("H");
		I.insRadice("I");
		L.insRadice("L");
		
			
		B.insprimoSottoAlbero(B.radice(), D);
		A.insprimoSottoAlbero(A.radice(), B);
		
		F.insprimoSottoAlbero(F.radice(), G);
		C.insprimoSottoAlbero(C.radice(), E);
		C.insSottoAlbero(C.primoFiglio(C.radice()), F);
		A.insSottoAlbero(A.primoFiglio(A.radice()), C);
		
		A.insSottoAlbero(A.succFratello(A.primoFiglio(A.radice())), H);
		
		I.insprimoSottoAlbero(I.radice(), L);
		
		A.insSottoAlbero(A.succFratello(A.primoFiglio(A.radice())), I);
		
		it=((AlberoPFFS)A).iterator();
		while(it.hasNext()){
			NodoPFFS v=(NodoPFFS)it.next();
			System.out.println(v);
		}
		
		
		System.out.println("Potature del sottalbero di 3 radicato in C");
		A.cancSottoAlbero(A.succFratello(A.primoFiglio(A.radice())));
	
		
		it=((AlberoPFFS)A).iterator();
		while(it.hasNext()){
			NodoPFFS v=(NodoPFFS)it.next();
			System.out.println(v);
		}
		
		System.out.println("Potature del sottalbero di 3 radicato in H");
		A.cancSottoAlbero(A.succFratello(A.succFratello(A.primoFiglio(A.radice()))));
		
		it=((AlberoPFFS)A).iterator();
		while(it.hasNext()){
			NodoPFFS v=(NodoPFFS)it.next();
			System.out.println(v);
		}
		
		
		
		
		
		System. out.println("Albero 4");
		
		Albero M = new AlberoPFFS();
		Albero N = new AlberoPFFS();
		Albero O = new AlberoPFFS();
		
		M.insRadice("A");
		N.insRadice("B");
		O.insRadice("C");
		
		M.insprimoSottoAlbero(M.radice(), N);
		M.insSottoAlbero(M.primoFiglio(M.radice()), O);
		
		it=((AlberoPFFS)M).iterator();
		while(it.hasNext()){
			NodoPFFS v=(NodoPFFS)it.next();
			System.out.println(v);
		}
		
		System.out.println("Ricerca primo figlio della radice di albero 3 nell' albero 4");
		try{
			M.primoFiglio(A.radice());
		}
		catch(EccezioneNodoInvalido e)
		{
			System.out.println(e);
		}
		catch(RuntimeException e)
		{
			System.out.println(e);
		}
		
		
		System.out.println("Potatura del sottalbero di 3 radicato in radice");
		A.cancSottoAlbero(A.radice());
		
		
		
		it=((AlberoPFFS)A).iterator();
		while(it.hasNext()){
			NodoPFFS v=(NodoPFFS)it.next();
			System.out.println(v);
		}
		

	}

}
