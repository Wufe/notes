

public enum tipoVisita {
 PRE, POS, IN
}
