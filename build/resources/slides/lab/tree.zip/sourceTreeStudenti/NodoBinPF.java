
public class NodoBinPF implements Nodo {
	public Object info;
	public NodoBinPF padre;
	public NodoBinPF sin;
	public NodoBinPF des;
	public AlberoBin albero; // per verificare che il nodo appartiene all'albero

	public NodoBinPF(Object info) {
		this.info = info;
	}
	public String toString(){
		return info.toString();
	}
}
