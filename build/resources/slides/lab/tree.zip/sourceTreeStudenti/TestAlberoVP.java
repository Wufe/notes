import java.util.Iterator;

public class TestAlberoVP {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		
		
		Albero A = new AlberoVP();
		Albero B = new AlberoVP();
		Albero C = new AlberoVP();
		Albero D = new AlberoVP();
		Albero E = new AlberoVP();
		Albero F = new AlberoVP();
		Albero G = new AlberoVP();
		Albero H = new AlberoVP();
		Albero I = new AlberoVP();
		Albero L = new AlberoVP();
	
		
		A.insRadice("A");
		B.insRadice("B");
		C.insRadice("C");
		D.insRadice("D");
		E.insRadice("E");
		F.insRadice("F");
		G.insRadice("G");

		H.insRadice("H");
		I.insRadice("I");
		L.insRadice("L");
		
		System.out.println("Albero 1");
		
		B.insprimoSottoAlbero(B.radice(), D);
		A.insprimoSottoAlbero(A.radice(), B);
		
		F.insprimoSottoAlbero(F.radice(), G);
		C.insprimoSottoAlbero(C.radice(), E);
		C.insSottoAlbero(C.primoFiglio(C.radice()), F);
		A.insSottoAlbero(A.primoFiglio(A.radice()), C);
		
		A.insSottoAlbero(A.succFratello(A.primoFiglio(A.radice())), H);
		
		I.insprimoSottoAlbero(I.radice(), L);
		
		A.insSottoAlbero(A.succFratello(A.primoFiglio(A.radice())), I);
		
		Iterator it=((AlberoVP)A).iterator();
		while(it.hasNext()){
			NodoVP v=(NodoVP)it.next();
			System.out.println(v);
		}
		
		System.out.println("Potature del sottalbero di 1 radicato in C");
		A.cancSottoAlbero(A.succFratello(A.primoFiglio(A.radice())));
	
		
		it=((AlberoVP)A).iterator();
		while(it.hasNext()){
			NodoVP v=(NodoVP)it.next();
			System.out.println(v);
		}
		
		System.out.println("Potature del sottalbero di 1 radicato in H");
		A.cancSottoAlbero(A.succFratello(A.succFratello(A.primoFiglio(A.radice()))));
		
		it=((AlberoVP)A).iterator();
		while(it.hasNext()){
			NodoVP v=(NodoVP)it.next();
			System.out.println(v);
		}
		
		System. out.println("Albero 2");
		
		Albero M = new AlberoVP();
		Albero N = new AlberoVP();
		Albero O = new AlberoVP();
		
		M.insRadice("A");
		N.insRadice("B");
		O.insRadice("C");
		
		M.insprimoSottoAlbero(M.radice(), N);
		M.insSottoAlbero(M.primoFiglio(M.radice()), O);
		

		 it=((AlberoVP)M).iterator();
		while(it.hasNext()){
			NodoVP v=(NodoVP)it.next();
			System.out.println(v);
		}
		
		
		System.out.println("Ricerca primo figlio della radice di albero 1 nell' albero 2");
		try{
			M.primoFiglio(A.radice());
		}
		catch(EccezioneNodoInvalido e)
		{
			System.out.println(e);
		}
		catch(RuntimeException e)
		{
			System.out.println(e);
		}
		
		
		
	
		
		
		System.out.println("Potature del sottalbero di 1 radicato in radice");
		A.cancSottoAlbero(A.radice());
		
		
		
				
		it=((AlberoVP)A).iterator();
		while(it.hasNext()){
			NodoVP v=(NodoVP)it.next();
			System.out.println(v);
		}
		
		
		

	}

}
